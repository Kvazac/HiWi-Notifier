# Isar Aerospace Student Job Notifier

This notifier uses Greenhouse's public Job Board API instead of scraping the rendered careers page.

Default matching is title-first for:
- Working Student
- Werkstudent
- Intern
- Internship
- Praktikant
- Praktikum

All locations are accepted by default. Thesis-student roles are excluded.

## GitHub setup

1. Copy the `isar/` directory, `isar-config.yml`, `data/isar-state.json`, and `.github/workflows/check-isar.yml` into the existing notifier repository.
2. Create a Discord webhook for the desired Isar channel.
3. Add repository secret `DISCORD_WEBHOOK_ISAR`.
4. Commit the files.
5. Open Actions → Check Isar Aerospace student jobs.
6. Run the generic test notification.
7. Run the real-listing test.
8. Run a normal check once to initialize state without flooding Discord.

The schedule runs twice per hour, at minute 11 and minute 41.
